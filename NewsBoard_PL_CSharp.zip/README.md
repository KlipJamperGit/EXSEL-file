# Prosty serwis aktualności — C# / .NET 8

Dwa osobne serwisy:
- `AdminSite` — dodawanie aktualności.
- `PublicSite` — publiczna strona z kartami aktualności.

## Uruchomienie
Wymagany .NET 8 SDK. Otwórz terminal w folderze `NewsHub`.

Terminal 1:
```bash
dotnet run --project AdminSite --urls http://localhost:5081
```

Terminal 2:
```bash
dotnet run --project PublicSite --urls http://localhost:5082
```

Panel: http://localhost:5081
Strona publiczna: http://localhost:5082

Strona publiczna pobiera dane przez HTTP z `http://localhost:5081/api/news`. Lista odświeża się automatycznie co 5 sekund. Można też użyć przycisku „Odśwież”.

Aktualności są na razie przechowywane w pamięci procesu AdminSite. Po ponownym uruchomieniu tego procesu lista będzie pusta.
