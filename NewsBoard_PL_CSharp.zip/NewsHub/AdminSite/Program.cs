using System.Collections.Concurrent;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
var news = new ConcurrentDictionary<int, NewsItem>();
var nextId = 0;

app.MapGet("/", () => Results.Content("""
<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Panel aktualności</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#101923;color:#edf4ff;font:16px Arial,sans-serif}main{max-width:760px;margin:35px auto;padding:24px;background:#1d3552;border-radius:16px}
h1{margin-top:0}label{display:block;margin:16px 0 6px;color:#c8d8ec}input{width:100%;padding:13px;border:0;border-radius:8px;font-size:16px}
button{margin-top:18px;padding:13px 20px;border:0;border-radius:8px;background:#f2c230;color:#161616;font-weight:bold;cursor:pointer}
.note{color:#a9c0dc;font-size:14px}article{padding:12px;margin-top:12px;background:#2a486a;border-radius:10px;overflow-wrap:anywhere}a{color:#ffe078}
</style></head><body><main><h1>Panel aktualności</h1><p class="note">Dodaj tytuł, adres zdjęcia i opcjonalny link do artykułu.</p>
<form id="form"><label for="title">Tytuł</label><input id="title" required maxlength="180" placeholder="Wpisz tytuł aktualności">
<label for="imageUrl">Adres zdjęcia (URL)</label><input id="imageUrl" type="url" required placeholder="https://example.com/zdjecie.jpg">
<label for="articleUrl">Link do artykułu (opcjonalnie)</label><input id="articleUrl" type="url" placeholder="https://example.com/artykul">
<button id="submit" type="submit">Opublikuj</button><p id="status" class="note"></p></form>
<h2>Opublikowane aktualności</h2><div id="items"></div></main>
<script>
const $=id=>document.getElementById(id);
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function load(){try{const r=await fetch('/api/news',{cache:'no-store'});if(!r.ok)throw Error();const a=await r.json();$('items').innerHTML=a.map(n=>`<article><b>${esc(n.title)}</b><br><a href="${esc(n.imageUrl)}" target="_blank" rel="noopener">Zdjęcie</a> · <a href="${esc(n.articleUrl||'#')}" target="_blank" rel="noopener">Artykuł</a></article>`).join('')||'<p class="note">Brak opublikowanych aktualności.</p>'}catch{$('items').innerHTML='<p class="note">Nie można pobrać listy.</p>'}}
$('form').addEventListener('submit',async e=>{e.preventDefault();$('submit').disabled=true;$('status').textContent='Publikowanie…';const body={title:$('title').value.trim(),imageUrl:$('imageUrl').value.trim(),articleUrl:$('articleUrl').value.trim()};try{const r=await fetch('/api/news',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r.ok){const d=await r.json().catch(()=>({}));throw Error(d.error||'Nie udało się opublikować.')}e.target.reset();$('status').textContent='Opublikowano pomyślnie.';await load()}catch(err){$('status').textContent=err.message}finally{$('submit').disabled=false}});
load();setInterval(load,5000);
</script></body></html>
""", "text/html; charset=utf-8"));

app.MapGet("/api/news", () => Results.Ok(news.Values.OrderByDescending(n => n.Id).ToArray()));
app.MapPost("/api/news", (CreateNews input) =>
{
    if (string.IsNullOrWhiteSpace(input.Title) || string.IsNullOrWhiteSpace(input.ImageUrl))
        return Results.BadRequest(new { error = "Tytuł i adres zdjęcia są wymagane." });
    if (!Uri.TryCreate(input.ImageUrl, UriKind.Absolute, out var img) || (img.Scheme != "http" && img.Scheme != "https"))
        return Results.BadRequest(new { error = "Adres zdjęcia musi zaczynać się od http:// lub https://." });
    if (!string.IsNullOrWhiteSpace(input.ArticleUrl) &&
        (!Uri.TryCreate(input.ArticleUrl, UriKind.Absolute, out var article) || (article.Scheme != "http" && article.Scheme != "https")))
        return Results.BadRequest(new { error = "Link do artykułu musi zaczynać się od http:// lub https://." });
    var item = new NewsItem(Interlocked.Increment(ref nextId), input.Title.Trim(), input.ImageUrl.Trim(), input.ArticleUrl?.Trim() ?? "", DateTimeOffset.UtcNow);
    news[item.Id] = item;
    return Results.Created($"/api/news/{item.Id}", item);
});
app.Run();

record CreateNews(string Title, string ImageUrl, string? ArticleUrl);
record NewsItem(int Id, string Title, string ImageUrl, string ArticleUrl, DateTimeOffset CreatedAt);
