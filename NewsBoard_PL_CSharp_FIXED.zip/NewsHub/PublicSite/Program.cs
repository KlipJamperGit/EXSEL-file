using System.Net.Http.Json;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient("NewsApi", client =>
{
    client.BaseAddress = new Uri(builder.Configuration["NewsApi:BaseUrl"] ?? "http://localhost:5081/");
    client.Timeout = TimeSpan.FromSeconds(5);
});
var app = builder.Build();

app.MapGet("/", async (IHttpClientFactory factory) =>
{
    List<NewsItem> items;
    try
    {
        using var client = factory.CreateClient("NewsApi");
        items = await client.GetFromJsonAsync<List<NewsItem>>("api/news", CancellationToken.None) ?? new();
    }
    catch
    {
        return Results.Content("""
<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aktualności</title>
<style>body{background:#101923;color:#fff;font:18px Arial;padding:40px}</style><h1>Aktualności</h1><p>Nie można połączyć się z panelem na porcie 5081.</p><p>Uruchom AdminSite i odśwież tę stronę.</p>
""", "text/html; charset=utf-8", statusCode: 503);
    }

    var cards = string.Join("\n", items.Select(n => $"""
<a class="card" href="{E(string.IsNullOrWhiteSpace(n.ArticleUrl) ? n.ImageUrl : n.ArticleUrl)}" target="_blank" rel="noopener">
<img src="{E(n.ImageUrl)}" alt=""><div class="shade"></div><div class="title">{E(n.Title)}</div><span class="tag">AKTUALNOŚĆ</span></a>
"""));
    var empty = items.Count == 0 ? "<p class=\"empty\">Brak aktualności. Dodaj pierwszą w panelu administracyjnym.</p>" : "";
    var html = $$"""
<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="5">
<title>Aktualności</title><style>
*{box-sizing:border-box}body{margin:0;background:#0d1722;color:#fff;font-family:Arial,sans-serif}
header{padding:22px 5vw;background:#13283e;border-bottom:1px solid #304c68;display:flex;align-items:center;justify-content:space-between}
.logo{font-size:clamp(25px,4vw,42px);font-weight:900;letter-spacing:1px}header small{color:#b6c8dc}
.wrap{max-width:1300px;margin:auto;padding:24px 20px}.hero{height:clamp(240px,40vw,520px);position:relative;overflow:hidden;border-radius:12px;background:#243a50;margin-bottom:28px}
.hero img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;opacity:.65}.hero h1{position:absolute;left:5%;bottom:8%;font-size:clamp(32px,7vw,76px);margin:0;text-shadow:0 3px 18px #000}.hero h1 span{background:#f2c230;color:#171717;padding:2px 10px}
h2{font-size:25px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:18px}
.card{height:260px;position:relative;display:block;border-radius:12px;overflow:hidden;background:#20364d;color:#fff;text-decoration:none;transition:transform .15s}.card:hover{transform:translateY(-3px)}
.card img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0}.shade{position:absolute;inset:0;background:linear-gradient(0deg,#060b12ee,#060b1220 75%)}
.title{position:absolute;bottom:45px;left:20px;right:20px;font-size:clamp(20px,2.5vw,28px);font-weight:800;text-shadow:0 2px 8px #000}
.tag{position:absolute;bottom:16px;left:20px;background:#f2c230;color:#171717;padding:6px 10px;font-size:12px;font-weight:bold;letter-spacing:1px}
.empty{padding:28px;background:#172a40;border-radius:10px;color:#c0d1e5}footer{text-align:center;color:#728ba5;padding:30px}
.refresh{color:#b6c8dc;font-size:13px}
</style></head><body><header><div class="logo">AKTUALNOŚCI</div><small>NAJNOWSZE PUBLIKACJE</small></header><main class="wrap">
<section class="hero"><img src="https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1600&q=80" alt=""><h1>NAJNOWSZE <span>WIADOMOŚCI</span></h1></section>
<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><h2>Ostatnie publikacje</h2><span class="refresh">Automatyczne odświeżanie co 5 sekund</span></div>
<section class="grid">{{cards}}</section>{{empty}}</main><footer>Aktualności · Dane pobierane z osobnego serwera HTTP</footer></body></html>
""";
    return Results.Content(html, "text/html; charset=utf-8");
});

app.Run();

static string E(string? value) => System.Net.WebUtility.HtmlEncode(value ?? "");
record NewsItem(int Id, string Title, string ImageUrl, string ArticleUrl, DateTimeOffset CreatedAt);
