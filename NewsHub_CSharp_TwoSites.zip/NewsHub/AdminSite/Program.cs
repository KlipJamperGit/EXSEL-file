using System.Collections.Concurrent;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
var news = new ConcurrentDictionary<int, NewsItem>();
var nextId = 0;

app.MapGet("/", () => Results.Content("""
<!doctype html><html lang="uk"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Панель новин</title><style>
*{box-sizing:border-box}body{margin:0;background:#101923;color:#edf4ff;font:16px Arial}main{max-width:760px;margin:35px auto;padding:24px;background:#1d3552;border-radius:16px}
label{display:block;margin:16px 0 6px;color:#c8d8ec}input{width:100%;padding:13px;border:0;border-radius:8px;font-size:16px}
button{margin-top:18px;padding:13px 20px;border:0;border-radius:8px;background:#f2c230;font-weight:bold;cursor:pointer}
.note{color:#a9c0dc;font-size:14px}article{padding:12px;margin-top:12px;background:#2a486a;border-radius:10px;overflow-wrap:anywhere}a{color:#ffe078}
</style><main><h1>Панель новин</h1><p class="note">Додай заголовок, URL фото та посилання на новину.</p>
<form id="f"><label>Заголовок</label><input id="title" required maxlength="180" placeholder="WAR DOGS — сезон 02">
<label>Посилання на фото (URL)</label><input id="imageUrl" type="url" required placeholder="https://example.com/image.jpg">
<label>Посилання на новину</label><input id="articleUrl" type="url" placeholder="https://example.com/news">
<button>Опублікувати</button><p id="status" class="note"></p></form><h2>Опубліковані новини</h2><div id="items"></div></main>
<script>
async function load(){let r=await fetch('/api/news');let a=await r.json();document.querySelector('#items').innerHTML=a.map(n=>`<article><b>${esc(n.title)}</b><br><a href="${esc(n.imageUrl)}" target="_blank">Фото</a> · <a href="${esc(n.articleUrl||'#')}" target="_blank">Новина</a></article>`).join('')||'<p class="note">Поки немає новин.</p>'}
function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
document.querySelector('#f').onsubmit=async e=>{e.preventDefault();let body={title:document.querySelector('#title').value,imageUrl:document.querySelector('#imageUrl').value,articleUrl:document.querySelector('#articleUrl').value};let r=await fetch('/api/news',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});document.querySelector('#status').textContent=r.ok?'Опубліковано!':'Помилка додавання';if(r.ok)e.target.reset();load()};load();
</script></html>
""", "text/html; charset=utf-8"));

app.MapGet("/api/news", () => Results.Ok(news.Values.OrderByDescending(n => n.Id).ToArray()));
app.MapPost("/api/news", (CreateNews input) =>
{
    if (string.IsNullOrWhiteSpace(input.Title) || string.IsNullOrWhiteSpace(input.ImageUrl))
        return Results.BadRequest(new { error = "Title and ImageUrl are required." });
    if (!Uri.TryCreate(input.ImageUrl, UriKind.Absolute, out var img) || (img.Scheme != "http" && img.Scheme != "https"))
        return Results.BadRequest(new { error = "ImageUrl must be an HTTP(S) URL." });
    if (!string.IsNullOrWhiteSpace(input.ArticleUrl) &&
        (!Uri.TryCreate(input.ArticleUrl, UriKind.Absolute, out var article) || (article.Scheme != "http" && article.Scheme != "https")))
        return Results.BadRequest(new { error = "ArticleUrl must be an HTTP(S) URL." });
    var item = new NewsItem(Interlocked.Increment(ref nextId), input.Title.Trim(), input.ImageUrl, input.ArticleUrl ?? "", DateTimeOffset.UtcNow);
    news[item.Id] = item;
    return Results.Created($"/api/news/{item.Id}", item);
});
app.Run();

record CreateNews(string Title, string ImageUrl, string? ArticleUrl);
record NewsItem(int Id, string Title, string ImageUrl, string ArticleUrl, DateTimeOffset CreatedAt);
