# WAR DOGS — збірник новин на C# (.NET 8)

Два окремі ASP.NET Core сайти:
- AdminSite — додаємо заголовок, URL фото та URL новини.
- PublicSite — показує картки новин і отримує їх через HTTP від AdminSite.

## Запуск
Потрібен .NET 8 SDK. Відкрий папку `NewsHub` у терміналі.

Термінал 1:
```bash
dotnet run --project AdminSite --urls http://localhost:5081
```

Термінал 2:
```bash
dotnet run --project PublicSite --urls http://localhost:5082
```

Панель: http://localhost:5081
Сайт новин: http://localhost:5082

PublicSite виконує HTTP GET до `http://localhost:5081/api/news` через `HttpClient`. JSON тут лише формат відповіді HTTP API, а не файл, який сайт читає напряму.

Поки що новини зберігаються в пам'яті AdminSite і зникнуть після його перезапуску. Посилання на фото має бути прямим URL зображення.
