# Zadanie 3 — Publisher CRUD (ASP.NET Core, C#)

Wymagany .NET 8 SDK. Uruchom `dotnet run` w folderze projektu.

Endpointy:
- GET `/api/publisher` — wszystkie książki
- GET `/api/publisher/{id}` — jedna książka
- POST `/api/publisher` — dodanie książki
- PUT `/api/publisher/{id}` — aktualizacja
- DELETE `/api/publisher/{id}` — usunięcie

Przykładowe body POST/PUT:
`{"title":"Pan Tadeusz","author":"Adam Mickiewicz"}`

Dane przechowywane są w pamięci i znikają po restarcie.
