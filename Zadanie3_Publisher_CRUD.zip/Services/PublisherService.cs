using Zadanie3.PublisherCrud.Models;
using Zadanie3.PublisherCrud.Repositories;
namespace Zadanie3.PublisherCrud.Services;
public class PublisherService
{
    private readonly PublisherRepository _repository;
    public PublisherService(PublisherRepository repository) => _repository = repository;
    public List<Book> GetAllBooks() => _repository.GetAll();
    public Book? GetBookById(int id) => _repository.GetById(id);
    public Book CreateBook(Book book) => _repository.Create(book);
    public bool UpdateBook(int id, Book book) => _repository.Update(id, book);
    public bool DeleteBook(int id) => _repository.Delete(id);
}
