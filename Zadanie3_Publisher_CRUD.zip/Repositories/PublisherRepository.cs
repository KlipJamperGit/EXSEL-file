using Zadanie3.PublisherCrud.Models;
namespace Zadanie3.PublisherCrud.Repositories;
public class PublisherRepository
{
    private readonly List<Book> _books = new();
    private int _nextId = 1;
    public List<Book> GetAll() => _books.ToList();
    public Book? GetById(int id) => _books.FirstOrDefault(b => b.Id == id);
    public Book Create(Book book)
    {
        var saved = new Book { Id = _nextId++, Title = book.Title, Author = book.Author };
        _books.Add(saved);
        return saved;
    }
    public bool Update(int id, Book updated)
    {
        var book = GetById(id);
        if (book is null) return false;
        book.Title = updated.Title;
        book.Author = updated.Author;
        return true;
    }
    public bool Delete(int id)
    {
        var book = GetById(id);
        return book is not null && _books.Remove(book);
    }
}
