using Zadanie3.PublisherCrud.Repositories;
using Zadanie3.PublisherCrud.Services;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddSingleton<PublisherRepository>();
builder.Services.AddScoped<PublisherService>();
var app = builder.Build();
app.MapControllers();
app.Run();
