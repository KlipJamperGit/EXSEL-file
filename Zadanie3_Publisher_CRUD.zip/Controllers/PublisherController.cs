using Microsoft.AspNetCore.Mvc;
using Zadanie3.PublisherCrud.Models;
using Zadanie3.PublisherCrud.Services;
namespace Zadanie3.PublisherCrud.Controllers;
[ApiController]
[Route("api/[controller]")]
public class PublisherController : ControllerBase
{
    private readonly PublisherService _service;
    public PublisherController(PublisherService service) => _service = service;

    [HttpGet]
    public ActionResult<List<Book>> GetAll() => Ok(_service.GetAllBooks());

    [HttpGet("{id:int}")]
    public ActionResult<Book> GetById(int id)
    {
        var book = _service.GetBookById(id);
        return book is null ? NotFound() : Ok(book);
    }

    [HttpPost]
    public ActionResult<Book> Create(Book book)
    {
        var created = _service.CreateBook(book);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpPut("{id:int}")]
    public IActionResult Update(int id, Book book) =>
        _service.UpdateBook(id, book) ? NoContent() : NotFound();

    [HttpDelete("{id:int}")]
    public IActionResult Delete(int id) =>
        _service.DeleteBook(id) ? NoContent() : NotFound();
}
